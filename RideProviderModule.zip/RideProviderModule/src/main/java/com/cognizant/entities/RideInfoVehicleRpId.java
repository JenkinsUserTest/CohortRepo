package com.cognizant.entities;

import jakarta.persistence.Embeddable;

@Embeddable
public class RideInfoVehicleRpId {
String vechileNo;
	
	String Rp_Id;
	
	public RideInfoVehicleRpId() {
		System.out.println("--RideInfoVehicleRpId--");
	}

	public String getVechileNo() {
		return vechileNo;
	}

	public void setVechileNo(String vechileNo) {
		this.vechileNo = vechileNo;
	}

	public String getRp_Id() {
		return Rp_Id;
	}

	public void setRp_Id(String rp_Id) {
		Rp_Id = rp_Id;
	}

	@Override
	public String toString() {
		return "RideInfoVehicleRpId [vechileNo=" + vechileNo + ", Rp_Id=" + Rp_Id + "]";
	}
	
}
