package com.cognizant.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.cognizant.main.RideProviderModuleApplication;

@SpringBootTest(classes = RideProviderModuleApplication.class)
class RideProviderModuleApplicationTests {

	@Test
	 public void contextLoads() {
	}

}
